The Twitter example distributed here includes the Codebird PHP library, which is licensed under GNU Public License, and therefore the Twitter example is also licensed under GNU Public License. 
