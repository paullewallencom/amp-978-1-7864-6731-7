alert('JavaScript... in an AMP page. Now I\'ve seen everything!');
