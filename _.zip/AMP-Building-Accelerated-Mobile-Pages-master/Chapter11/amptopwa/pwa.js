alert('Just a JS alert, in PWA page, nothing unusual here');
